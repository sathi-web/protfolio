# Display small intro particals

A Pen created on CodePen.io. Original URL: [https://codepen.io/yash30389/pen/bGpyMQm](https://codepen.io/yash30389/pen/bGpyMQm).

